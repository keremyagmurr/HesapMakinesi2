﻿using System;
using Microsoft.Maui.Controls;
using System.Data;

namespace HesapMakinesi2
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        // Ekrana yaz
        void TusBasilinca(object sender, EventArgs e)
        {
            if (sender is Button tus)
            {
                Gosterge.Text += tus.Text;
            }
        }

        // C tusu
        void TemizleTusu(object sender, EventArgs e)
        {
            Gosterge.Text = string.Empty;
        }

        // = tusu
        void EsittirTusu(object sender, EventArgs e)
        {
            try
            {
                string ifade = Gosterge.Text;

                if (ifade.Contains("/0"))
                {
                    Gosterge.Text = "Hata!";
                    return;
                }

                // DataTable ile islemi degerlendir
                var sonuc = new DataTable().Compute(ifade, null);

                Gosterge.Text = sonuc.ToString();
            }

            catch (Exception)
            {
                Gosterge.Text = "Hata!";
            }
        }
    }
}
