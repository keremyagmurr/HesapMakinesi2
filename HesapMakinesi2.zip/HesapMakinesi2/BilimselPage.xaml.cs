﻿using System;
using System.Data;
using Microsoft.Maui.Controls;

namespace HesapMakinesi2
{
    public partial class BilimselPage : ContentPage
    {
        bool dereceModu = true;

        public BilimselPage()
        {
            InitializeComponent();
        }

        void TusBasildi(object sender, EventArgs e)
        {
            if (sender is Button tus)
                Gosterge.Text += tus.Text;
        }

        void TemizleTusu(object sender, EventArgs e)
        {
            Gosterge.Text = string.Empty;
        }

        void DereceRadyanDegistir(object sender, EventArgs e)
        {
            dereceModu = !dereceModu;
        }

        void BilimselTusBasildi(object sender, EventArgs e)
        {
            if (sender is Button tus)
            {
                string islem = tus.Text;
                try
                {
                    string ifade = Gosterge.Text;

                    if (string.IsNullOrWhiteSpace(ifade))
                        return;

                    double sayi = Convert.ToDouble(new DataTable().Compute(ifade, null));

                    double sonuc = 0;

                    switch (islem)
                    {
                        case "√":
                            sonuc = Math.Sqrt(sayi);
                            break;
                        case "x²":
                            sonuc = Math.Pow(sayi, 2);
                            break;
                        case "xʸ":
                            Gosterge.Text = sayi.ToString() + "^";
                            return;
                        case "eˣ":
                            sonuc = Math.Exp(sayi);
                            break;
                        case "sin":
                            {
                                double aci = dereceModu ? DereceyiRadyanaCevir(sayi) : sayi;
                                sonuc = Math.Sin(aci);
                                break;
                            }
                        case "cos":
                            {
                                double aci = dereceModu ? DereceyiRadyanaCevir(sayi) : sayi;
                                sonuc = Math.Cos(aci);
                                break;
                            }
                        case "tan":
                            {
                                double aci = dereceModu ? DereceyiRadyanaCevir(sayi) : sayi;
                                sonuc = Math.Tan(aci);
                                break;
                            }
                        case "log":
                            sonuc = Math.Log10(sayi);
                            break;
                    }

                    Gosterge.Text = sonuc.ToString();
                }
                catch
                {
                    Gosterge.Text = "Hata!";
                }
            }
        }

        void EsittirTusu(object sender, EventArgs e)
        {
            try
            {
                string ifade = Gosterge.Text;

                if (ifade.Contains("/0"))
                {
                    Gosterge.Text = "Hata!";
                    return;
                }
                if (ifade.Contains("^"))
                {
                    var parcalar = ifade.Split('^');
                    if (parcalar.Length == 2)
                    {
                        double taban = Convert.ToDouble(new DataTable().Compute(parcalar[0], null));
                        double us = Convert.ToDouble(new DataTable().Compute(parcalar[1], null));
                        double sonuc = Math.Pow(taban, us);
                        Gosterge.Text = sonuc.ToString();
                        return;
                    }
                }

                var sonucDT = new DataTable().Compute(ifade, null);
                Gosterge.Text = sonucDT.ToString();
            }
            catch
            {
                Gosterge.Text = "Hata!";
            }
        }

        double DereceyiRadyanaCevir(double derece)
        { 
            return derece * Math.PI / 180.0; 
        }
    }
}
