[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "HesapMakinesi2")]
[assembly: XmlnsDefinition("http://schemas.microsoft.com/dotnet/maui/global", "HesapMakinesi2.Pages")]
